import { describe, it, expect } from "vitest";
import { Grid } from "../src/Grid.js";

describe("Grid", () => {
  const baseW = 100;
  const baseH = 80;
  const scale = 1;

  it("builds lines spanning the origin at given spacing", () => {
    const grid = new Grid(baseW, baseH, scale, 10, 1);
    const lines = grid.node.children.map((c) => c.id);
    expect(lines).toContain("v-0");
    expect(lines).toContain("h-0");
    expect(lines).toContain("axis-x");
    expect(lines).toContain("axis-y");
  });

  it("rebuilds when spacing changes", () => {
    const grid = new Grid(baseW, baseH, scale, 20, 1);
    const initialCount = grid.node.children.length;
    grid.update(10, 1);
    expect(grid.node.children.length).toBeGreaterThan(initialCount);
  });

  it("rebuilds when zoom changes", () => {
    const grid = new Grid(baseW, baseH, scale, 20, 1);
    const initialIds = grid.node.children.map((c) => c.id);
    grid.update(20, 2); // zoom in, same spacing
    const newIds = grid.node.children.map((c) => c.id);
    expect(newIds).not.toEqual(initialIds);
  });
});
