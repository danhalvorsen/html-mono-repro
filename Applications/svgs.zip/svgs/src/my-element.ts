import { LitElement, html } from "lit";
import { customElement } from "lit/decorators.js";
import { CompositeNode, SceneRenderer, Circle, Rectangle, Triangle } from "@monorepo/core-composition-svg";
import { Grid } from "./Grid.js";
import "./Zoom.js";

const BASE_VIEW_WIDTH = 4096;
const BASE_VIEW_HEIGHT = 2049;
const SCALE = 3;
const MIN_ZOOM = 0.1;
const MAX_ZOOM = 6;

class SceneCanvas {
  readonly root: CompositeNode;
  private grid: Grid;
  private zoom = 1;
  private gridIndex = 0;

  constructor(
    private readonly baseWidth: number,
    private readonly baseHeight: number,
    private readonly sceneScale: number,
    private readonly gridSteps: number[]
  ) {
    this.root = new CompositeNode("root");
    this.grid = new Grid(this.baseWidth, this.baseHeight, this.sceneScale, this.gridSteps[this.gridIndex], this.zoom);
    this.root.addChild(this.grid.node);
    this.rebuildTransform();
  }

  setZoom(value: number) {
    const clamped = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, value));
    this.zoom = clamped;
    this.rebuildTransform();
    this.grid.update(this.gridSteps[this.gridIndex], this.zoom);
  }

  cycleGrid() {
    this.gridIndex = (this.gridIndex + 1) % this.gridSteps.length;
    this.grid.update(this.gridSteps[this.gridIndex], this.zoom);
  }

  private rebuildTransform() {
    this.root.setLocalMatrix(
      new DOMMatrix()
        .translateSelf(this.baseWidth / 2, this.baseHeight / 2)
        .scaleSelf(this.sceneScale * this.zoom, -this.sceneScale * this.zoom)
    );
  }
}

@customElement("svg-demo")
export class SvgDemo extends LitElement {
 
  render() {
    return html`
      <zoom-control id="zoom" .min=${MIN_ZOOM} .max=${MAX_ZOOM} .value=${1}></zoom-control>
      <svg id="scene" viewBox="0 0 4096 2049" aria-label="Composed SVG scene"></svg>
    `;
  }

  protected firstUpdated(): void {
    const svg = this.renderRoot.querySelector<SVGSVGElement>("#scene");
    const zoomControl = this.renderRoot.querySelector<HTMLElement & { value: number }>(
      "#zoom"
    ) as HTMLElement & { value: number } | null;
    if (!svg) return;

    // Clear any previous scene root/groups (e.g., after HMR) before wiring a new tree.
    svg.replaceChildren();

    const gridSteps = [20, 50, 100, 200];
    const canvas = new SceneCanvas(BASE_VIEW_WIDTH, BASE_VIEW_HEIGHT, SCALE, gridSteps);
    // initialize zoom to current step
    let zoom = 1;
    canvas.setZoom(zoom);
    const root = canvas.root;

    const cluster = new CompositeNode("cluster");
    cluster.setLocalMatrix(new DOMMatrix().translateSelf(-120, -40).rotateSelf(0, 0, -4));
    root.addChild(cluster);

    const backdrop = new Rectangle("backdrop", 120, 120, { fill: "#0f1d35", stroke: "#1f2a44", strokeWidth: 3 });
    backdrop.setLocalMatrix(new DOMMatrix().translateSelf(-60, -60));
    cluster.addChild(backdrop);

    const emitter = new Circle("emitter", 36, { fill: "#22d3ee", stroke: "#0ea5e9", strokeWidth: 4 });
    emitter.setLocalMatrix(new DOMMatrix().translateSelf(20, 0));
    cluster.addChild(emitter);

    const satellites = new CompositeNode("satellites");
    satellites.setLocalMatrix(new DOMMatrix().translateSelf(120, 30).rotateSelf(0, 0, -12));
    cluster.addChild(satellites);

    const tri = new Triangle("triangle", [
      { x: 0, y: 120 },
      { x: 120, y: 120 },
      { x: 60, y: 0 },
    ], { fill: "#c084fc", stroke: "#a855f7", strokeWidth: 4 });
    tri.setLocalMatrix(new DOMMatrix().translateSelf(20, 20));
    satellites.addChild(tri);

    const renderer = new SceneRenderer(svg, root);

    const zoomTo = (value: number) => {
      zoom = value;
      canvas.setZoom(zoom);
      if (zoomControl) zoomControl.value = zoom;
      renderer.markDirty();
    };

    // Wire zoom control
    zoomControl?.addEventListener("zoom-change", (event: Event) => {
      const { value } = (event as CustomEvent<{ value: number }>).detail;
      zoomTo(value);
    });

    // Click to cycle grid spacing (ignore clicks on zoom control overlay)
    svg.addEventListener("click", (evt) => {
      const composedPath = evt.composedPath();
      if (composedPath.some((el) => (el as Element).tagName?.toLowerCase() === "zoom-control")) return;
      canvas.cycleGrid();
      renderer.markDirty();
    });

  }
}

declare global {
  interface HTMLElementTagNameMap {
    "svg-demo": SvgDemo;
  }
}
