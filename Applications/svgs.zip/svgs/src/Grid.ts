import { CompositeNode, Line } from "@monorepo/core-composition-svg";

export class Grid {
  readonly node: CompositeNode;
  private spacing: number;
  private zoom: number;
  private readonly baseWidth: number;
  private readonly baseHeight: number;
  private readonly sceneScale: number;

  constructor(baseWidth: number, baseHeight: number, sceneScale: number, spacing: number, zoom: number) {
    this.baseWidth = baseWidth;
    this.baseHeight = baseHeight;
    this.sceneScale = sceneScale;
    this.spacing = spacing;
    this.zoom = zoom;
    this.node = new CompositeNode("grid");
    this.rebuild();
  }

  update(spacing: number, zoom: number) {
    this.spacing = spacing;
    this.zoom = zoom;
    this.rebuild();
  }

  private rebuild() {
    while (this.node.children.length) {
      this.node.removeChild(this.node.children[0]);
    }

    const halfW = (this.baseWidth / (this.sceneScale * this.zoom)) / 2;
    const halfH = (this.baseHeight / (this.sceneScale * this.zoom)) / 2;
    const spacing = this.spacing;
    const startX = Math.floor(-halfW / spacing) * spacing;
    const startY = Math.floor(-halfH / spacing) * spacing;

    for (let x = startX; x <= halfW; x += spacing) {
      this.node.addChild(new Line(`v-${x}`, [{ x, y: -halfH }, { x, y: halfH }], { stroke: "#1f2937", strokeWidth: 1 }));
    }
    for (let y = startY; y <= halfH; y += spacing) {
      this.node.addChild(new Line(`h-${y}`, [{ x: -halfW, y }, { x: halfW, y }], { stroke: "#1f2937", strokeWidth: 1 }));
    }
    this.node.addChild(new Line("axis-x", [{ x: -halfW, y: 0 }, { x: halfW, y: 0 }], { stroke: "#334155", strokeWidth: 2 }));
    this.node.addChild(new Line("axis-y", [{ x: 0, y: -halfH }, { x: 0, y: halfH }], { stroke: "#334155", strokeWidth: 2 }));
  }
}
