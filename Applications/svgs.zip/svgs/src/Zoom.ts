import { LitElement, css, html } from "lit";
import { customElement, property } from "lit/decorators.js";

const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));

@customElement("zoom-control")
export class ZoomControl extends LitElement {
  static styles = css`
    :host {
      position: fixed;
      left: 24px;
      top: 80px;
      user-select: none;
      touch-action: none;
      z-index: 10;
    }
    svg {
      display: block;
    }
    line,
    circle {
      vector-effect: non-scaling-stroke;
    }
  `;

  @property({ type: Number }) value = 1;
  @property({ type: Number }) min = 0.1;
  @property({ type: Number }) max = 6;

  private readonly trackHeight = 300;

  render() {
    const t = clamp((this.value - this.min) / (this.max - this.min || 1), 0, 1);
    const y = this.trackHeight * (1 - t);
    return html`
      <svg
        width="48"
        height=${this.trackHeight}
        viewBox="-24 0 48 ${this.trackHeight}"
        @pointerdown=${this.onPointer}
      >
        <line x1="0" y1="0" x2="0" y2=${this.trackHeight} stroke="#1f2937" stroke-width="8" stroke-linecap="round" />
        <circle
          cx="0"
          cy=${y}
          r="12"
          fill="#22d3ee"
          stroke="#0ea5e9"
          stroke-width="3"
          @pointerdown=${this.onPointer}
        />
      </svg>
    `;
  }

  private onPointer(evt: PointerEvent) {
    evt.preventDefault();
    const svg = this.shadowRoot?.querySelector("svg");
    if (!svg) return;
    const rect = svg.getBoundingClientRect();
    const localY = clamp(evt.clientY - rect.top, 0, this.trackHeight);
    const t = 1 - localY / this.trackHeight;
    const next = this.min + t * (this.max - this.min);
    this.value = next;
    this.dispatchEvent(new CustomEvent("zoom-change", { detail: { value: next } }));
  }
}

declare global {
  interface HTMLElementTagNameMap {
    "zoom-control": ZoomControl;
  }
}
