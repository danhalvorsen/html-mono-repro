import { defineConfig } from "vitest/config";
import path from "path";

export default defineConfig({
  test: {
    globals: true,
    environment: "node",
    include: ["tests/**/*.test.ts"]
  },

  resolve: {
    alias: {
      "@my-graphics/core-logger": path.resolve(__dirname, "src")
    }
  }
});
