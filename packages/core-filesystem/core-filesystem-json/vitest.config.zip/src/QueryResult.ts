// // File: my-graphics-engine/packages/core.filesystem.json/src/QueryResult.ts

// import { ITemplate } from '@my-graphics/core.template';

// export interface Match<T> {
//   path: string[];
//   value: T;
// }

// export interface QueryResult<T> {
//   readonly matches: Match<T>[];

//   /**
//    * Add a new match.
//    */
//   add(path: string[], value: T): void;

//   /**
//    * Format the result using a custom template.
//    */
//   toTemplateString(template: ITemplate<QueryResult<T>>): string;

//   /**
//    * Return a compact string (e.g., for console or test output).
//    */
//   toString(): string;

//   /**
//    * Count of total matches.
//    */
//   count(): number;
// }
