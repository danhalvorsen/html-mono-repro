 
// import { File } from "@my-graphics/core.filesystem";
// import { Err, Ok, Result } from "@my-graphics/core.design-patterns";
// import { QueryResult } from "./QueryResult";

// // -------------------- Interfaces --------------------

// /**
//  * Base interface for evaluating queries on parsed JSON data.
//  */
// export interface IJsonQuery<T extends {} | null> {
//   match(json: T): boolean;
//   load(file: File): Promise<Result<T, Error>>;
//   report?(json: T): QueryResult<T>;
// }

// /**
//  * Extended fluent query interface for chaining predicates.
//  */
// export interface JSONQuery<T extends {} | null> extends IJsonQuery<T> {
//   Load(file: File): JSONQuery<T>;
//   Where(predicate: (value: T, path: string[]) => boolean): JSONQuery<T>;
//   ContainsValue(value: T): JSONQuery<T>;
//   KeyEquals<K extends keyof T>(key: K, expectedValue: T[K]): JSONQuery<T>;
//   ExistsKey<K extends keyof T>(key: K): JSONQuery<T>;
// }

// // -------------------- Implementation --------------------

// type JSONPredicate<T> = (value: T, path: string[]) => boolean;

// /**
//  * Concrete implementation of JSONQuery<T> with predicate chaining and reporting.
//  */
// export class JSONQueryImpl<T extends {} | null> implements JSONQuery<T> {
//   private readonly checks: JSONPredicate<T>[] = [];

//   private lastFile?: File;
//   private parsedJson?: T;

//   Load(file: File): this {
//     this.lastFile = file;
//     return this;
//   }

//   async load(file: File): Promise<Result<T, Error>> {
//     try {
//       const content = await file.read();
//       const parsed = JSON.parse(content) as T;
//       this.parsedJson = parsed;
//       return  Ok(parsed);
//     } catch (err) {
//       return  Err(err instanceof Error ? err : new Error("Unknown error during JSON load"));
//     }
//   }

//   Where(predicate: JSONPredicate<T>): this {
//     this.checks.push(predicate);
//     return this;
//   }

//   ContainsValue(value: T): this {
//     this.checks.push((v) => v === value);
//     return this;
//   }

//   KeyEquals<K extends keyof T>(key: K, expectedValue: T[K]): this {
//     this.checks.push((value, path) => path[path.length - 1] === key && value === expectedValue);
//     return this;
//   }

//   ExistsKey<K extends keyof T>(key: K): this {
//     this.checks.push((_, path) => path.includes(key as string));
//     return this;
//   }

//   match(json: T): boolean {
//     const zipped = this.traverseOnce(json);
//     return this.checks.every((check) =>
//       seq(zipped).where(({ value, path }: { value: any; path: string[] }) => check(value, path)).any()
//     );
//   }

//   report(json: T): QueryResult<T> {
//     const result = new QueryResult<T>();
//     const zipped = this.traverseOnce(json);

//     for (const check of this.checks) {
//       for (const { value, path } of zipped) {
//         if (check(value, path)) {
//           result.add(path, value);
//         }
//       }
//     }

//     return result;
//   }

//   private traverseOnce(json: T): Array<{ value: any; path: string[] }> {
//     return traverse(json).reduce(function (
//       acc: Array<{ value: any; path: string[] }>,
//       value: any
//     ) {
//       acc.push({ value, path: this.path as string[] });
//       return acc;
//     }, []);
//   }
// }
