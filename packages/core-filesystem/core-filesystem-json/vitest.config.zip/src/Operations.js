"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JsonQueryBuilderImpl = exports.JSONQueryImpl = void 0;
var traverse_1 = require("traverse");
var powerseq_1 = require("powerseq");
var JSONQueryImpl_1 = require("./JSONQueryImpl");
Object.defineProperty(exports, "JSONQueryImpl", { enumerable: true, get: function () { return JSONQueryImpl_1.JSONQueryImpl; } });
var JSONQueryImpl = /** @class */ (function () {
    function JSONQueryImpl() {
        this.checks = [];
    }
    JSONQueryImpl.prototype.where = function (predicate) {
        this.checks.push(predicate);
        return this;
    };
    JSONQueryImpl.prototype.containsValue = function (expectedValue) {
        this.checks.push(function (value) { return value === expectedValue; });
        return this;
    };
    JSONQueryImpl.prototype.keyEquals = function (key, expectedValue) {
        this.checks.push(function (value, path) { return path[path.length - 1] === key && value === expectedValue; });
        return this;
    };
    JSONQueryImpl.prototype.existsKey = function (key) {
        this.checks.push(function (_, path) { return path.includes(key); });
        return this;
    };
    /**
     * Use powerseq to match JSON with fluent, expressive syntax.
     */
    JSONQueryImpl.prototype.match = function (json) {
        var allNodes = Array.from((0, traverse_1.default)(json).nodes());
        var allPaths = (0, traverse_1.default)(json).paths();
        return this.checks.every(function (check) {
            var zipped = allNodes.map(function (v, i) { return ({ value: v, path: allPaths[i] }); });
            return (0, powerseq_1.seq)(zipped)
                .where(function (_a) {
                var value = _a.value, path = _a.path;
                return check(value, path);
            })
                .any();
        });
    };
    return JSONQueryImpl;
}());
exports.JSONQueryImpl = JSONQueryImpl;
var JsonQueryBuilderImpl = /** @class */ (function () {
    function JsonQueryBuilderImpl() {
        this.query = new JSONQueryImpl_1.JSONQueryImpl();
    }
    JsonQueryBuilderImpl.prototype.where = function (predicate) {
        this.query.where(predicate);
        return this;
    };
    JsonQueryBuilderImpl.prototype.containsValue = function (value) {
        this.query.containsValue(value);
        return this;
    };
    JsonQueryBuilderImpl.prototype.keyEquals = function (key, expectedValue) {
        this.query.keyEquals(key, expectedValue);
        return this;
    };
    JsonQueryBuilderImpl.prototype.existsKey = function (key) {
        this.query.existsKey(key);
        return this;
    };
    JsonQueryBuilderImpl.prototype.build = function () {
        return this.query;
    };
    JsonQueryBuilderImpl.create = function () {
        return new JsonQueryBuilderImpl();
    };
    return JsonQueryBuilderImpl;
}());
exports.JsonQueryBuilderImpl = JsonQueryBuilderImpl;
