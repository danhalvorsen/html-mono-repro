// // File: my-graphics-engine/packages/core.filesystem-json/src/JsonQueryBuilderImpl.ts

// import { JSONQuery, JSONQueryImpl } from "./JSONQuery";
// /**
//  * Builder interface for constructing a JSONQuery<T> in a fluent style.
//  */
// export interface JsonQueryBuilder<T extends {} | null> {
//   /**
//    * Add a predicate that must return true for at least one (value, path) pair.
//    */
//   where(predicate: (value: any, path: string[]) => boolean): JsonQueryBuilder<T>;

//   /**
//    * Match if any value in the JSON equals the provided value.
//    */
//   containsValue(value: any): JsonQueryBuilder<T>;

//   /**
//    * Match if a key has an exact value match.
//    */
//   keyEquals<K extends keyof T>(key: K, expectedValue: T[K]): JsonQueryBuilder<T>;

//   /**
//    * Match if a key exists in any node.
//    */
//   existsKey<K extends keyof T>(key: K): JsonQueryBuilder<T>;

//   /**
//    * Finalize and return the built JSONQuery<T>.
//    */
//   build(): JSONQuery<T>;
// }

// /**
//  * Concrete builder implementation for JSONQuery<T>.
//  */
// export class JsonQueryBuilderImpl<T extends {} | null> implements JsonQueryBuilder<T> {
//   private readonly query: JSONQueryImpl<T>;

//   constructor() {
//     this.query = new JSONQueryImpl<T>();
//   }

//   where(predicate: (value: any, path: string[]) => boolean): JsonQueryBuilder<T> {
//     this.query.Where(predicate as (value: T, path: string[]) => boolean);
//     return this;
//   }

//   containsValue(value: any): JsonQueryBuilder<T> {
//     this.query.ContainsValue(value as T);
//     return this;
//   }

//   keyEquals<K extends keyof T>(key: K, expectedValue: T[K]): JsonQueryBuilder<T> {
//     this.query.KeyEquals(key, expectedValue);
//     return this;
//   }

//   existsKey<K extends keyof T>(key: K): JsonQueryBuilder<T> {
//     this.query.ExistsKey(key);
//     return this;
//   }

//   build(): JSONQuery<T> {
//     return this.query;
//   }
// }
