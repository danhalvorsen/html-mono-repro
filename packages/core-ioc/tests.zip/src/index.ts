﻿import "reflect-metadata";
import "core-logger";

// Public API only:
export * from "./IServiceCollection.js";
export * from "./ServiceCollectionSyringe.js"