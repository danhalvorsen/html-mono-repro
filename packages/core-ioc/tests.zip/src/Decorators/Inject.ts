import { inject } from "tsyringe";

export interface InjectOptions {
  isOptional?: boolean;
}

export function Inject(
  token: any,
  options?: boolean | InjectOptions
) {
  let finalOptions: InjectOptions | undefined = undefined;

  if (typeof options === "boolean") {
    finalOptions = { isOptional: options };
  } else if (typeof options === "object") {
    finalOptions = options;
  }

  return inject(token, finalOptions as any);
}
