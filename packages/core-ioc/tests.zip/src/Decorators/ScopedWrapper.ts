export class ScopedWrapper<T = unknown> {
  value?: T;

  constructor(value?: T) {
    this.value = value;
  }
}

export const ScopedWrapperImpl = ScopedWrapper;