import "reflect-metadata";
import { injectable } from "tsyringe";
import type { InternalLifecycle } from "../lifecycle.js";
import { Lifecycle } from "../lifecycle.js";

export function Injectable(lifecycle: InternalLifecycle = Lifecycle.Transient) {
  return function (target: any) {
    // Register with tsyringe exactly as-is
    injectable()(target);

    // Store lifecycle only
    Reflect.defineMetadata("core-ioc:lifecycle", lifecycle, target);
  };
}
