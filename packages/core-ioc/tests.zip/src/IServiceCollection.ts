export interface IServiceCollection {
  addSingleton<T>(service: new (...args: any[]) => T, impl: new (...args: any[]) => T): this;
  addTransient<T>(service: new (...args: any[]) => T, impl: new (...args: any[]) => T): this;
  addScoped<T>(service: new (...args: any[]) => T, impl: new (...args: any[]) => T): this;
  resolve<T>(service: new (...args: any[]) => T): T;
}
