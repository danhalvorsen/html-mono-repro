import "reflect-metadata";
import {
  container as tsContainer,
  injectable,
  inject,
  Lifecycle,
} from "tsyringe";

import type { IServiceCollection } from "./IServiceCollection.js";

export const Inject = inject;
export const Injectable = injectable;

export class ServiceCollectionSyringe implements IServiceCollection {
  private readonly registrations: Array<() => void> = [];
  private built = false;

  addSingleton<T>(
    service: new (...args: any[]) => T,
    impl: new (...args: any[]) => T
  ): this {
    this.registrations.push(() =>
      tsContainer.register(service, impl, {
        lifecycle: Lifecycle.Singleton,
      })
    );
    return this;
  }

  addTransient<T>(
    service: new (...args: any[]) => T,
    impl: new (...args: any[]) => T
  ): this {
    this.registrations.push(() =>
      tsContainer.register(service, impl, {
        lifecycle: Lifecycle.Transient,
      })
    );
    return this;
  }

  addScoped<T>(
    service: new (...args: any[]) => T,
    impl: new (...args: any[]) => T
  ): this {
    this.registrations.push(() =>
      tsContainer.register(service, impl, {
        lifecycle: Lifecycle.ContainerScoped,
      })
    );
    return this;
  }

  resolve<T>(service: new (...args: any[]) => T): T {
    for (const r of this.registrations) r();

    const registration = (tsContainer as any)._registry.get(service);

    // Optional: if not registered → return undefined
    if (!registration) {
      const paramOptions =
        Reflect.getMetadata("tsyringe:inject_tokens", service) || [];
      const isOptional = paramOptions.some(
        (p: any) => p.token === service && p.options?.isOptional
      );
      if (isOptional) return undefined as any;
    }
    return tsContainer.resolve(service);
  }
}
