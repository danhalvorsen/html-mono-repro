import type { InternalLifecycle } from "./lifecycle.js";

export class ServiceDescriptor<T = any> {
  instance: T | null = null;

  constructor(
    public readonly implementation: new (...args: any[]) => T,
    public readonly lifecycle: InternalLifecycle
  ) {}
}