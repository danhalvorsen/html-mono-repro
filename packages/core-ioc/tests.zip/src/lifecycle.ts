export enum Lifecycle {
  Singleton = "singleton",
  Scoped = "scoped",
  Transient = "transient"
}

// Internal helper factories
export const lifecycleSingleton = () => Lifecycle.Singleton;
export const lifecycleScoped = () => Lifecycle.Scoped;
export const lifecycleTransient = () => Lifecycle.Transient;

export type InternalLifecycle = Lifecycle;
