import "reflect-metadata";
import { describe, it, expect } from "vitest";
import { Injectable } from "../src/Decorators/Injectable.js";
import { Inject } from "../src/Decorators/Inject.js";
import { Lifecycle } from "../src/lifecycle.js";
import { ServiceCollectionSyringe } from "../src/ServiceCollectionSyringe.js";

describe("Constructor Injection", () => {
  it("injects multiple dependencies", () => {
    const sc = new ServiceCollectionSyringe();

    @Injectable(Lifecycle.Transient)
    class A {}

    @Injectable(Lifecycle.Transient)
    class B {}

    @Injectable(Lifecycle.Transient)
    class C {
      constructor(
        @Inject(A) public a: A,
        @Inject(B) public b: B
      ) {}
    }

    sc.addTransient(A, A);
    sc.addTransient(B, B);
    sc.addTransient(C, C);

    const c = sc.resolve(C);

    expect(c).toBeInstanceOf(C);
    expect(c.a).toBeInstanceOf(A);
    expect(c.b).toBeInstanceOf(B);
  });
});
