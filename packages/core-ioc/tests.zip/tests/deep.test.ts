import "reflect-metadata";
import { describe, it, expect } from "vitest";
import { ServiceCollectionSyringe } from "../src/ServiceCollectionSyringe.js";
import { Injectable } from "../src/Decorators/Injectable.js";
import { Inject } from "../src/Decorators/Inject.js";
import { Lifecycle } from "../src/lifecycle.js";

@Injectable(Lifecycle.Transient)
class D {
  value = 10;
}

@Injectable(Lifecycle.Transient)
class C {
  constructor(@Inject(D) public d: D) {}
}

@Injectable(Lifecycle.Transient)
class B {
  constructor(@Inject(C) public c: C) {}
}

@Injectable(Lifecycle.Transient)
class A {
  constructor(@Inject(B) public b: B) {}
}

describe("Deep Dependency Chain", () => {
  it("resolves A → B → C → D", () => {
    const sc = new ServiceCollectionSyringe();

    sc.addTransient(A, A)
      .addTransient(B, B)
      .addTransient(C, C)
      .addTransient(D, D);

    const a = sc.resolve(A);

    expect(a.b.c.d.value).toBe(10);
  });
});
