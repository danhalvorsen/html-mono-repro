import "reflect-metadata";
import { describe, it, expect } from "vitest";
import { ServiceCollectionSyringe } from "../src/ServiceCollectionSyringe.js";
import { Injectable } from "../src/Decorators/Injectable.js";
import { Inject } from "../src/Decorators/Inject.js";
import { Lifecycle } from "../src/lifecycle.js";

class Missing {}

@Injectable(Lifecycle.Transient)
class A {
  constructor(
    @Inject(Missing, true) public maybe?: Missing
  ) {}
}

describe("Optional Injection", () => {
  it("injects undefined when service missing", () => {
    const sc = new ServiceCollectionSyringe();
    sc.addTransient(A, A);

    const a = sc.resolve(A);
    expect(a.maybe).toBeUndefined();
  });
});
