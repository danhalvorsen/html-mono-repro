import { describe, it, expect } from "vitest";
import { ServiceCollectionSyringe } from "../src/ServiceCollectionSyringe.js";

describe("Basic DI Behavior", () => {
  it("resolves a transient", () => {
    class A {}

    const sc = new ServiceCollectionSyringe();
    sc.addTransient(A, A);

    const a1 = sc.resolve(A);
    const a2 = sc.resolve(A);

    expect(a1).not.toBe(a2);
  });

  it("resolves a singleton", () => {
    class A {}

    const sc = new ServiceCollectionSyringe();
    sc.addSingleton(A, A);

    const a1 = sc.resolve(A);
    const a2 = sc.resolve(A);

    expect(a1).toBe(a2);
  });

  it("throws for missing", () => {
    const sc = new ServiceCollectionSyringe();
    class X {}

    expect(() => sc.resolve(X)).toThrowError();
  });
});
