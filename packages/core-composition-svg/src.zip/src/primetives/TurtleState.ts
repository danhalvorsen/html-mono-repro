import { Point } from "./Point";

// ---------- Turtle State ----------
export interface TurtleState {
    readonly position: Point;
    readonly headingDeg: number;
}
