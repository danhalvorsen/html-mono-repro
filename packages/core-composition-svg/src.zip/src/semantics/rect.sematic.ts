/**
 * Represents a rectangle with explicit vertex and edge semantics.
 * Useful for spatial reasoning, constraint validation, and geometry layout.
 */
export class SemanticRectangle {
  public v0: [number, number]; // Top-left
  public v1: [number, number]; // Top-right
  public v2: [number, number]; // Bottom-right
  public v3: [number, number]; // Bottom-left

  constructor(
    public readonly x: number,
    public readonly y: number,
    public readonly width: number,
    public readonly height: number,
    public readonly rotation: number = 0 // degrees
  ) {
    this.v0 = [x, y];
    this.v1 = [x + width, y];
    this.v2 = [x + width, y + height];
    this.v3 = [x, y + height];
  }

  /** Returns the four edges (v0→v1, v1→v2, v2→v3, v3→v0). */
  get edges(): Array<[[number, number], [number, number]]> {
    return [
      [this.v0, this.v1],
      [this.v1, this.v2],
      [this.v2, this.v3],
      [this.v3, this.v0],
    ];
  }

  /** Returns the center of the rectangle. */
  get center(): [number, number] {
    return [this.x + this.width / 2, this.y + this.height / 2];
  }

  /** Returns the rotated vertices (if rotation ≠ 0). */
  get rotatedVertices(): [number, number][] {
    if (this.rotation === 0) return [this.v0, this.v1, this.v2, this.v3];

    const angle = (this.rotation * Math.PI) / 180;
    const cos = Math.cos(angle);
    const sin = Math.sin(angle);
    const [cx, cy] = this.center;

    const rotate = ([vx, vy]: [number, number]): [number, number] => [
      cx + (vx - cx) * cos - (vy - cy) * sin,
      cy + (vx - cx) * sin + (vy - cy) * cos,
    ];

    return [this.v0, this.v1, this.v2, this.v3].map(rotate);
  }

  /** Returns bounding box after rotation */
  get rotatedBounds() {
    const points = this.rotatedVertices;
    const xs = points.map(p => p[0]);
    const ys = points.map(p => p[1]);
    return {
      left: Math.min(...xs),
      right: Math.max(...xs),
      top: Math.min(...ys),
      bottom: Math.max(...ys),
    };
  }

  /** Semantic helper: check whether a point lies inside the rectangle (rotation-aware). */
  contains(px: number, py: number): boolean {
    const { left, right, top, bottom } = this.rotatedBounds;
    return px >= left && px <= right && py >= top && py <= bottom;
  }

  /** Computes intersection or overlap ratio with another rectangle. */
  overlapRatio(other: SemanticRectangle): number {
    const a = this.rotatedBounds;
    const b = other.rotatedBounds;
    const overlapWidth = Math.max(0, Math.min(a.right, b.right) - Math.max(a.left, b.left));
    const overlapHeight = Math.max(0, Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top));
    const overlapArea = overlapWidth * overlapHeight;
    const selfArea = this.width * this.height;
    return overlapArea / selfArea;
  }
}